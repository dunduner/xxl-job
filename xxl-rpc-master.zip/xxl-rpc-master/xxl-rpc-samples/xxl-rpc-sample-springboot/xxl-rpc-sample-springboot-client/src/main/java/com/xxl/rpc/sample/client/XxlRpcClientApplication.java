package com.xxl.rpc.sample.client;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author xuxueli 2018-10-20 13:05:56
 */
@SpringBootApplication
public class XxlRpcClientApplication {

	public static void main(String[] args) {
        SpringApplication.run(XxlRpcClientApplication.class, args);
	}

}