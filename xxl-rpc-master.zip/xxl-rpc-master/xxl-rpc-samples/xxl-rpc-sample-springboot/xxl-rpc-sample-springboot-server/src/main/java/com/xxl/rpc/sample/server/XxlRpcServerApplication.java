package com.xxl.rpc.sample.server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author xuxueli 2018-10-20 13:05:56
 */
@SpringBootApplication
public class XxlRpcServerApplication {

	public static void main(String[] args) {
        SpringApplication.run(XxlRpcServerApplication.class, args);
	}

}


