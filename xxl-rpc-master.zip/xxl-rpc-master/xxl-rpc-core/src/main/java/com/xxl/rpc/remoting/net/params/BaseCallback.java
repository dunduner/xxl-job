package com.xxl.rpc.remoting.net.params;

/**
 * @author xuxueli 2018-10-19
 */
public abstract class BaseCallback {

    public abstract void run() throws Exception;

}
